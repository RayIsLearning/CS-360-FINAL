package com.example.project2;

import android.database.sqlite.SQLiteOpenHelper;

public class dbase extends SQLiteOpenHelper {//create database
    private static final String DATABASE_NAME = "dbase.db";
    private static dbase mDatabase;
    public static dbase getInstance(Context context) {//checks for database and creates a new one
        if (mDatabase == null) {
            mDatabase = new weight_app_database(context);
        }
        return mDatabase;
    }
    private static final class LogTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "username";
        private static final String COL_PASSWORD = "password";
    }

    private static final class TarTable {
        private static final String TABLE = "target_weight";
        private static final String COL_ID = "_id";
        private static final String COL_TARGET = "target";
    }

    private static final class DalTable {
        private static final String TABLE = "daily_weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }

}
